function aumentarLikes(btn){
    let megusta = document.getElementById("megusta"+btn.id[3]);
    megusta.innerText++;
}